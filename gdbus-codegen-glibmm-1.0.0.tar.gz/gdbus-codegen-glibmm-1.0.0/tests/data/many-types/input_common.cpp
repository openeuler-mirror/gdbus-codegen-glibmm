#include "OUTPUT_DIR/input_common.h"

#include <cstring>

